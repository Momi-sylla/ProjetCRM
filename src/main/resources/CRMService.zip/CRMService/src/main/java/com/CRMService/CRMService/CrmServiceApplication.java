package com.CRMService.CRMService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.io.IOException;

@SpringBootApplication
public class CrmServiceApplication {

	public static void main(String[] args) throws IOException {
		SpringApplication.run(CrmServiceApplication.class, args);
	}

}
